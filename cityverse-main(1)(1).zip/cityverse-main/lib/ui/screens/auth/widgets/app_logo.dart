import 'package:flutter/material.dart';

import '../../../../utils/ui_utils.dart';

class AppLogo extends StatelessWidget {
  const AppLogo({super.key});

  @override
  Widget build(context) => SizedBox(
        height: 70,
        width: 180,
        child: Image.asset(
          UiUtils.getLogoImagePath("VarCity.png"),
        ),
      );
}
