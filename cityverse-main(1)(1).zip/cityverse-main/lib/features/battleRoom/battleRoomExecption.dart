// ignore_for_file: file_names

class BattleRoomException implements Exception {
  final String? errorMessageCode;

  BattleRoomException({required this.errorMessageCode});

  @override
  String toString() => errorMessageCode!;
}
