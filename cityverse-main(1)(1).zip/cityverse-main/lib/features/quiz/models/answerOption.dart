class AnswerOption {
  final String? id;
  final String? title;

  AnswerOption({this.id, this.title});
}
