// ignore_for_file: file_names

class CoinHistoryException implements Exception {
  final String errorMessageCode;

  CoinHistoryException({required this.errorMessageCode});
  @override
  String toString() => errorMessageCode;
}
