// ignore_for_file: file_names

class BadgesException implements Exception {
  final String errorMessageCode;

  BadgesException({required this.errorMessageCode});

  @override
  String toString() => errorMessageCode;
}
