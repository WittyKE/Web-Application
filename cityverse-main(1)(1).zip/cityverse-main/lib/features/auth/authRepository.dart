import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutterquiz/features/auth/auhtException.dart';
import 'package:flutterquiz/features/auth/authLocalDataSource.dart';
import 'package:flutterquiz/features/auth/authRemoteDataSource.dart';
import 'package:flutterquiz/features/auth/cubits/authCubit.dart'
    as authCubit; // Using 'as' to import with a prefix

class AuthRepository {
  static final AuthRepository _authRepository = AuthRepository._internal();
  late AuthLocalDataSource _authLocalDataSource;
  late AuthRemoteDataSource _authRemoteDataSource;

  factory AuthRepository() {
    _authRepository._authLocalDataSource = AuthLocalDataSource();
    _authRepository._authRemoteDataSource = AuthRemoteDataSource();
    return _authRepository;
  }

  AuthRepository._internal();

  //to get auth details stored in hive box
  Map<String, dynamic> getLocalAuthDetails() {
    return {
      "isLogin": AuthLocalDataSource.checkIsAuth(),
      "jwtToken": AuthLocalDataSource.getJwtToken(),
      "firebaseId": AuthLocalDataSource.getUserFirebaseId(),
      "authProvider":
          getAuthProviderFromString(AuthLocalDataSource.getAuthType()),
    };
  }

  void setLocalAuthDetails(
      {String? jwtToken,
      String? firebaseId,
      String? authType,
      bool? authStatus,
      bool? isNewUser}) {
    _authLocalDataSource.changeAuthStatus(authStatus);

    _authLocalDataSource.setUserFirebaseId(firebaseId);
    _authLocalDataSource.setAuthType(authType);
  }

  // First we sign in the user with the given provider then add user details
  Future<Map<String, dynamic>> signInUser(
    authCubit.AuthProvider authProvider, {
    required String email,
    required String password,
    required String verificationId,
    required String smsCode,
  }) async {
    try {
      final result = await _authRemoteDataSource.signInUser(
        authProvider,
        email: email,
        password: password,
        smsCode: smsCode,
        verificationId: verificationId,
      );
      final user = result['user'] as User;
      bool isNewUser = result['isNewUser'] as bool;

      if (authProvider == authCubit.AuthProvider.email) {
        // Check if user exists or not
        final isUserExist = await _authRemoteDataSource.isUserExist(user.uid);
        // If user does not exist, add them to the database
        if (!isUserExist) {
          isNewUser = true;
          final registeredUser = await _authRemoteDataSource.addUser(
            email: user.email ?? "",
            firebaseId: user.uid,
            mobile: user.phoneNumber ?? "",
            name: user.displayName ?? "",
            type: getAuthTypeString(authProvider),
            profile: user.photoURL ?? "",
          );
          print("JWT TOKEN is : ${registeredUser['api_token']}");

          // Store JWT token
          await AuthLocalDataSource.setJwtToken(
              registeredUser['api_token'].toString());
        } else {
          // Get JWT token of the user
          final jwtToken = await _authRemoteDataSource.getJWTTokenOfUser(
              firebaseId: user.uid, type: getAuthTypeString(authProvider));

          // Store JWT token
          await AuthLocalDataSource.setJwtToken(jwtToken);

          await _authRemoteDataSource.updateFcmId(
              firebaseId: user.uid, userLoggingOut: false);
        }
      } else {
        if (isNewUser) {
          //
          final registeredUser = await _authRemoteDataSource.addUser(
            email: user.email ?? "",
            firebaseId: user.uid,
            mobile: user.phoneNumber ?? "",
            name: user.displayName ?? "",
            type: getAuthTypeString(authProvider),
            profile: user.photoURL ?? "",
          );

          // Store JWT token
          print("JWT TOKEN is : ${registeredUser['api_token']}");
          await AuthLocalDataSource.setJwtToken(registeredUser['api_token']);
        } else {
          // Get JWT token of the user
          final jwtToken = await _authRemoteDataSource.getJWTTokenOfUser(
              firebaseId: user.uid, type: getAuthTypeString(authProvider));

          print("Jwt token $jwtToken");
          // Store JWT token
          await AuthLocalDataSource.setJwtToken(jwtToken);
          //
          await _authRemoteDataSource.updateFcmId(
              firebaseId: user.uid, userLoggingOut: false);
        }
      }
      return {
        "user": user,
        "isNewUser": isNewUser,
      };
    } catch (e) {
      print(e.toString());
      signOut(authProvider);
      throw AuthException(errorMessageCode: e.toString());
    }
  }

  // To sign up user
  Future<void> signUpUser(String email, String password) async {
    try {
      await _authRemoteDataSource.signUpUser(email, password);
    } catch (e) {
      signOut(authCubit.AuthProvider.email);
      throw AuthException(errorMessageCode: e.toString());
    }
  }

  Future<void> signOut(authCubit.AuthProvider? authProvider) async {
    // Remove FCM token when the user logs out
    try {
      _authRemoteDataSource.updateFcmId(
          firebaseId: AuthLocalDataSource.getUserFirebaseId(),
          userLoggingOut: true);
      _authRemoteDataSource.signOut(authProvider);
      setLocalAuthDetails(
          authStatus: false,
          authType: "",
          jwtToken: "",
          firebaseId: "",
          isNewUser: false);
    } catch (e) {}
  }

  String getAuthTypeString(authCubit.AuthProvider provider) {
    String authType;
    if (provider == authCubit.AuthProvider.fb) {
      authType = "fb";
    } else if (provider == authCubit.AuthProvider.gmail) {
      authType = "gmail";
    } else if (provider == authCubit.AuthProvider.mobile) {
      authType = "mobile";
    } else if (provider == authCubit.AuthProvider.apple) {
      authType = "apple";
    } else {
      authType = "email";
    }
    return authType;
  }

  // To add user's data to the database. This will be in use when authenticating using phoneNumber
  Future<Map<String, dynamic>> addUserData(
      {String? firebaseId,
      String? type,
      String? name,
      String? profile,
      String? mobile,
      String? email,
      String? referCode,
      String? friendCode}) async {
    try {
      final result = await _authRemoteDataSource.addUser(
          email: email,
          firebaseId: firebaseId,
          friendCode: friendCode,
          mobile: mobile,
          name: name,
          profile: profile,
          referCode: referCode,
          type: type);

      // Update JWT token
      await AuthLocalDataSource.setJwtToken(result['api_token'].toString());

      return Map.from(result); //
    } catch (e) {
      signOut(authCubit.AuthProvider.mobile);
      throw AuthException(errorMessageCode: e.toString());
    }
  }

  authCubit.AuthProvider getAuthProviderFromString(String? value) {
    authCubit.AuthProvider authProvider;
    if (value == "fb") {
      authProvider = authCubit.AuthProvider.fb;
    } else if (value == "gmail") {
      authProvider = authCubit.AuthProvider.gmail;
    } else if (value == "mobile") {
      authProvider = authCubit.AuthProvider.mobile;
    } else if (value == "apple") {
      authProvider = authCubit.AuthProvider.apple;
    } else {
      authProvider = authCubit.AuthProvider.email;
    }
    return authProvider;
  }
}
