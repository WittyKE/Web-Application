# CityVerse Quiz App

## Get the packages

```shell
flutter pub get
```

## If Running the app for IoS, do this before

```shell
cd ios
pod install
cd ..
```

## Run the app

```shell
flutter run
```